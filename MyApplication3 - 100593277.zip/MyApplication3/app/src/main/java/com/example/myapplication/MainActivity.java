package com.example.myapplication;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigDecimal;

public class MainActivity extends AppCompatActivity {
        private EditText mMortgage;
        private EditText mInterestRate;
        private EditText mloanTenure;
        private TextView mTextViewResult;
        private Button mButtonAdd;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                mMortgage = findViewById(R.id.mortgage);
                mInterestRate = findViewById(R.id.interestRate);
                mloanTenure = findViewById(R.id. loanTenure);
                mTextViewResult = findViewById(R.id.textview_result);
                mButtonAdd = findViewById(R.id.button_add);

                mButtonAdd.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                if (mMortgage.getText().toString().length() == 0) {
                                        mMortgage.setText("0");
                                }

                                if (mInterestRate.getText().toString().length() == 0) {
                                        mInterestRate.setText("0");
                                }

                                if ( mloanTenure.getText().toString().length() == 0) {
                                        mloanTenure.setText("0");
                                }

                                //Retrieving data in order to perform caculations
                                double mort = Double.parseDouble(mMortgage.getText().toString());
                                double rate = Double.parseDouble(mInterestRate.getText().toString());
                                double tenure = Double.parseDouble(mloanTenure.getText().toString());
                                rate = rate / (12*100);

                                double calculatedEmi =  ((mort*rate*Math.pow(1+rate,tenure))
                                        / (Math.pow(1+rate,tenure)-1));

                                //Sets to 2 decimal places maximum
                                mTextViewResult.setText(String.valueOf
                                        (String.format("%.2f", calculatedEmi)));
                        }
                });

        }
}